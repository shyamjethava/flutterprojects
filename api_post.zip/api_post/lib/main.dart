import 'dart:convert';

import 'package:api_post/second.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
void main()
{
  runApp(MaterialApp(
    home: post_method(),
  ));
}
class post_method extends StatefulWidget {
  const post_method({Key? key}) : super(key: key);

  @override
  State<post_method> createState() => _post_methodState();
}

class _post_methodState extends State<post_method> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            TextFormField(controller: t1,
              decoration: InputDecoration(
                border: UnderlineInputBorder(),
                labelText: 'username',
              ),
            ),
            TextField(controller: t2,),
            ElevatedButton(onPressed: () async {
              String name=t1.text;
              String job=t2.text;
          var url = Uri.https('reqres.in', 'api/users');
          var response = await http.post(url, body: {"name":name,"job":job});

          print(response.body);
          print(response.statusCode);

          Map m=jsonDecode(response.body);
          print("${m['name']}");
          print("${m['job']}");
          print("${m['id']}");
          print("${m['createdAt']}");

          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return second(m);
          },));

        }, child: Text("submit")),
          ],
        ),
      ),
    );
  }
}

