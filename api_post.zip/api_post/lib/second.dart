import 'package:flutter/material.dart';

class second extends StatefulWidget {
  Map m;
  second(this.m);
  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {

  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [SizedBox(height: 40,),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text('${widget.m['id']}'),
                Column(
                  children: [
                    Text('${widget.m['name']}'),
                    Text('${widget.m['job']}'),
                  ],
                ),
                Text('${widget.m['createdAt']}'),
              ],
            )
          ],
        )
      ),
    );
  }


}
