import 'package:api_list/datafile.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
//import 'package:loading_animation_widget/loading_animation_widget.dart';

void main() {
  runApp(MaterialApp(
    home: api_list(),
  ));
}
