import 'dart:convert';
import 'package:api_list/student.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class api_list extends StatefulWidget {
  const api_list({Key? key}) : super(key: key);

  @override
  State<api_list> createState() => _api_listState();
}

class _api_listState extends State<api_list> {
  late student s;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  getdata() async {
    var url = Uri.https('reqres.in', 'api/unknown');
    var response = await http.get(url);
    try {
      Map<String, dynamic> m = jsonDecode(response.body);
      s = student.fromJson(m);
      setState(() {});
    } catch (e) {
      print("something wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("demo"),
      ),
      body: SafeArea(
          child: Scaffold(
        body: Column(
          children: [
            Text('${s.page}'),
            Text('${s.perPage}'),
            Text('${s.total}'),
            Text('${s.totalPages}'),
            ListView.builder(
              shrinkWrap: true,
              itemCount: s.data!.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('${s.data![index].name}'),
                  subtitle: Text('${s.data![index].color}'),
                  trailing: Text('${s.data![index].year}'),
                  leading: Text('${s.data![index].id}'),
                );
              },
            ),
          ],
        ),
      )),
    );
  }
}
