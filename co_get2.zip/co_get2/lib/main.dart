import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(
    home: get2(),
  ));
}
class get2 extends StatefulWidget {
  const get2({Key? key}) : super(key: key);

  @override
  State<get2> createState() => _get2State();
}

class _get2State extends State<get2> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  TextEditingController t3=TextEditingController();
  String valued="fruits";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              Container(padding: EdgeInsets.only(left: 5,top: 5),alignment: Alignment.topLeft,child: Text("select category",style: TextStyle(fontSize: 20),),),
              Container(height: 50,
                child: DropdownButton(icon: Icon(Icons.keyboard_double_arrow_down),focusColor: Colors.blue,isExpanded: true,value: "$valued",items:[
                  DropdownMenuItem(child: Text("fruits"),value: "fruits",),
                  DropdownMenuItem(child: Text("vegetable"),value: "vegetable",),
                  DropdownMenuItem(child: Text("fast food"),value: "fast food",),
                ], onChanged: (value) {
                  setState(() {
                    valued=value!;
                  });
                },),
              ),
              
              Container(padding: EdgeInsets.only(left: 20,top: 5),alignment: Alignment.topLeft,child: Text("name",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 20,top: 5),
                child: TextFormField(
                  controller: t1,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Container(padding: EdgeInsets.only(left: 20,top: 5),alignment: Alignment.topLeft,child: Text("MRP",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 20,top: 5),
                child: TextFormField(
                  controller: t2,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Container(padding: EdgeInsets.only(left: 20,top: 5),alignment: Alignment.topLeft,child: Text("Discription",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 20,top: 5),
                child: TextFormField(
                  controller: t3,
                  maxLines: 5,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(height: 30,),
              Container(height: 50,width: 200,
                child: ElevatedButton(onPressed: () async {

                 String name=t1.text;
                 String catagory=valued;
                 print(catagory);
                 String mrp=t2.text;
                 String disc=t3.text;
                  var url = Uri.parse('https://storemydata.000webhostapp.com/pro2insert.php?name=$name&catagory=$catagory&mrp=$mrp&description=$disc');
                  var response = await http.get(url);
                  print('Response status: ${response.statusCode}');
                  print('Response body: ${response.body}');

                }, child: Text("submit",style: TextStyle(fontSize: 20),)),
              )
            ],
          ),
        ),
      ),
    );
  }
}
