import 'dart:convert';

import 'package:co_get/second.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main()
{
  runApp(MaterialApp(home: login(),));
}
class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  TextEditingController t1=TextEditingController();
  TextEditingController t2=TextEditingController();
  TextEditingController t3=TextEditingController();
  String type="vegetable";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Add Category",textAlign: TextAlign.center,),),
        body: SingleChildScrollView(
          child: SafeArea(child: Column(
            children: [
              Container(padding: EdgeInsets.only(left: 5,top: 5),alignment: Alignment.topLeft,child: Text("name",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 20,top: 5),
                child: TextFormField(
                  controller: t1,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),

              Container(padding: EdgeInsets.only(left: 5,top: 5),alignment: Alignment.topLeft,child: Text("type",style: TextStyle(fontSize: 20),),),

              Row(
                children: [
                    Expanded(child: Radio(value: "vegetable", groupValue: type, onChanged: (value) {
                        setState(() {
                          type=value.toString();

                        });
                    },)),
                  Text("vegetable",style: TextStyle(fontSize: 15),),
                  Expanded(child: Radio(value: "non veg", groupValue: type, onChanged: (value) {
                      setState(() {
                          type=value.toString();
                      });
                  },)),
                  Text("Non-vegetable",style: TextStyle(fontSize: 15),),

                  Expanded(child: Radio(value: "eggatarian", groupValue: type, onChanged: (value) {
                              setState(() {
                                type=value.toString();

                              });
                  },)),
                  Text("egetarian",style: TextStyle(fontSize: 15),),

                  Expanded(child: Radio(value: "vegan", groupValue: type, onChanged: (value) {
                        setState(() {
                          type=value.toString();

                        });
                  },)),
                  Text("vegan",style: TextStyle(fontSize: 15),),

                ],
              ),

              Container(padding: EdgeInsets.only(left: 5,top: 5),alignment: Alignment.topLeft,child: Text("Description",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 20,top: 5),
                child: TextFormField(
                  maxLength: 50,
                  controller: t2,
                  maxLines: 5,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Container(padding: EdgeInsets.only(left: 5,top: 5),alignment: Alignment.topLeft,child: Text("Minimum qty.",style: TextStyle(fontSize: 20),),),
              Container(padding: EdgeInsets.only(left: 20,right: 300,top: 5),
                child: TextFormField(
                  controller: t3,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                ),
              ),

              Container(margin: EdgeInsets.only(top: 50),width: 200,height: 50,
                child: ElevatedButton(onPressed: () async {

                 String cat_type=type;
                 String cat_name=t1.text;
                 String cat_description=t2.text;
                 String cat_qty=t3.text;

                    var url = Uri.parse('https://storemydata.000webhostapp.com/insert.php?cat_type=$cat_type&cat_name=$cat_name&cat_description=$cat_description&cat_qty=$cat_qty');
                    print(cat_description);
                    var response = await http.get(url);
                    print('Response status: ${response.statusCode}');
                    print('Response body: ${response.body}');

            }, child: Text("submit",style: TextStyle(fontSize: 20),)),
              ),
            ],
          )),
        ),
    );
  }
}
