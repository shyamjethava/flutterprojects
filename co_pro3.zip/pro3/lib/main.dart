import 'package:flutter/material.dart';

void  main()
{
  runApp(MaterialApp(home: pro3(),));
}
class pro3 extends StatefulWidget {
  const pro3({Key? key}) : super(key: key);

  @override
  State<pro3> createState() => _pro3State();
}

class _pro3State extends State<pro3> {
  String city="varachha";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("project 3"),),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height: 15,),
            Container(margin: EdgeInsets.only(left: 10),alignment: Alignment.topLeft,child: Text("surat Gujarat",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),),
            SizedBox(height: 15,),
            DropdownButton(value: city,isExpanded: true,items: [
              DropdownMenuItem(child: Text("varachha",style: TextStyle(fontSize: 20),),value: "varachha",),
              DropdownMenuItem(child: Text("udhna",style: TextStyle(fontSize: 20),),value: "udhana",),
              DropdownMenuItem(child: Text("limbayat",style: TextStyle(fontSize: 20),),value: "limbayat",),
            ], onChanged: (value) {
              city=value!;
              setState(() {

              });
            },),
            SizedBox(height: 15,),
            Container(margin: EdgeInsets.only(left: 10),alignment: Alignment.topLeft,child: Text("address type",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),)
          ],
        ),
      ),
    );
  }
}
